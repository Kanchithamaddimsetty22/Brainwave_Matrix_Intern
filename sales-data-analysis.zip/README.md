# 📊 Sales Data Analysis

This project analyzes sales data from a commercial store to extract insights like total revenue, profit, and category performance.

## 📁 Dataset

**Fields:**
- `Date`: Date of sale
- `Product`: Name of the product
- `Category`: Product category
- `Units Sold`: Number of units sold
- `Unit Price`: Selling price per unit
- `Total Revenue`: Revenue generated
- `Cost Price`: Purchase cost per unit

## 🔍 Key Insights

- Total revenue and profit
- Profit by product category
- Top-selling product

## 🛠️ Tools Used

- Python 🐍
- Pandas
- Matplotlib
- Seaborn

## 📈 Sample Output

A bar chart showing profit by category, and textual insights printed in the console.
